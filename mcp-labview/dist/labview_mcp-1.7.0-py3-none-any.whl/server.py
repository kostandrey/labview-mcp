#!/usr/bin/env python3
"""labview-mcp: MCP stdio server wrapping LabVIEW extraction/scripting tools.

Zero dependencies (Python stdlib only). Implements the Model Context
Protocol over stdio: newline-delimited JSON-RPC 2.0.

Tools cover three capabilities:
  1. Static .vi analysis  - extract_vi, list_artifacts, crop_image, stitch_cases
  2. LabVIEW docs         - search_docs, read_doc (offline CHM mirror),
                            search_ni_docs, fetch_ni_doc (live ni.com backend)
  3. Live LabVIEW via COM - gateway (ping/analyze/listmem/wires/errors +
                            write verbs), gateway_batch, arrread (array
                            in/out runtime verification), manage_processes
"""
import html as html_mod
import glob
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import urllib.parse

# Paths. Everything is anchored on ONE root (default: the local project
# layout); override with env vars to install the server elsewhere:
#   LABVIEW_SKILL_ROOT      root of the LabView skill checkout (gateway,
#                           knowledge base, help mirror, style codes)
#   LABVIEW_MCP_SCRIPTS     driver scripts dir (default <root>/mcp-labview/scripts)
SKILL_ROOT = os.environ.get("LABVIEW_SKILL_ROOT", r"C:\LabView skill")
ROOT = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.environ.get("LABVIEW_MCP_SCRIPTS",
                         os.path.join(SKILL_ROOT, "mcp-labview", "scripts"))
WORKROOT = os.path.join(SKILL_ROOT, "_service", "extract")  # gitignored
HELP_DIR = os.path.join(SKILL_ROOT, "help")
GATEWAY_VI = os.path.join(SKILL_ROOT, "gateway", "Gateway.vi")
ARRREAD_EXE = os.path.join(SKILL_ROOT, "skill-labview-code",
                           "scripts", "arrread.exe")
# Scripting Server (borrowed JanGoebel labview_assistant, converted to
# LV2020; see skill-labview-code/references/scripting-server-2020.md)
LVA_DIR = os.path.join(SKILL_ROOT, "scripting-server")
LVA_WORKERS = os.path.join(LVA_DIR, "Scripting Server")
LVA_WORKER_VBS = os.path.join(SCRIPTS, "lva_worker.vbs")
LVA_SESSION_VI = os.path.join(SKILL_ROOT, "gateway", "LVA", "LVA Session.vi")
LVA_CALL_VBS = os.path.join(SCRIPTS, "lva_call.vbs")
# 64-BIT cscript REQUIRED for lva_session: the 32-bit client fails
# SetControlValue/GetControlValue on the session VI with 0x1B6 "Object
# doesn't support this property or method" (verified 2026-10-27 both
# bitnesses; out-of-process COM itself works cross-bitness).
CSCRIPT = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"),
                       "System32", "cscript.exe")
if not os.path.isfile(CSCRIPT):
    CSCRIPT = "cscript"
# Allowed-paths guardrail config (borrowed from the Scripting Server's
# config.json Allowed Paths whitelist). Missing file = unrestricted.
ALLOWED_PATHS_FILE = os.path.join(ROOT, "allowed_paths.json")
SERVER_NAME = "labview-mcp"
SERVER_VERSION = "1.7.0"


def log(msg):
    print("[%s] %s" % (SERVER_NAME, msg), file=sys.stderr, flush=True)


def run(cmd, timeout=180):
    """Run a command, return combined readable output (never raises)."""
    try:
        r = subprocess.run(cmd, capture_output=True, text=True,
                           errors="replace", timeout=timeout)
        out = (r.stdout or "").strip()
        err = (r.stderr or "").strip()
        if r.returncode != 0:
            return "EXIT %s\nstdout:\n%s\nstderr:\n%s" % (r.returncode, out, err)
        return out if out else err
    except subprocess.TimeoutExpired:
        return "ERROR: command timed out after %ss" % timeout
    except Exception as e:
        return "ERROR: %s" % e


def strip_html(s):
    s = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", s)
    # Keep commented-out content: Zoomin pages (docs-be.ni.com) embed the whole
    # article inside one large HTML comment - only the markers must go.
    s = re.sub(r"<!--", " ", s)
    s = re.sub(r"-->", " ", s)
    s = re.sub(r"<[^>]+>", " ", s)
    s = html_mod.unescape(s)
    return re.sub(r"[ \t\r\f\v]+", " ", s)


def walk_files(root, limit=5000):
    out = []
    for dirpath, _dirnames, filenames in os.walk(root):
        for fn in filenames:
            p = os.path.join(dirpath, fn)
            try:
                st = os.stat(p)
            except OSError:
                continue
            out.append((p, st.st_size, st.st_mtime))
            if len(out) >= limit:
                return out
    return out


def cap(text, n):
    if len(text) <= n:
        return text
    return text[:n] + "\n... [truncated, %s chars total]" % len(text)


# --------------------------------------------------------------------------
# Tool implementations
# --------------------------------------------------------------------------

def tool_extract_vi(args):
    vi = args["vi_path"]
    if not os.path.isfile(vi):
        return "ERROR: source not found: %s" % vi
    base = os.path.splitext(os.path.basename(vi))[0]
    out = args.get("out_dir") or os.path.join(WORKROOT, base)
    os.makedirs(out, exist_ok=True)
    res = run(["cscript", "//nologo", os.path.join(SCRIPTS, "lv_extract2.vbs"), vi, out],
              timeout=420)
    files = walk_files(out)
    listing = "\n".join("  %-60s %9d bytes" % (os.path.relpath(p, out), sz)
                        for p, sz, _m in files)
    text = "extract_vi result for: %s\nwork dir: %s\n\n%s\n\n--- artifacts (%d) ---\n%s\n" % (
        vi, out, res, len(files), listing)
    strings_path = os.path.join(out, base + "_strings.txt")
    if os.path.isfile(strings_path):
        with open(strings_path, "r", errors="replace") as f:
            raw = f.read()
        text += ("\n--- strings export preview (%d of %d chars; full file: %s) ---\n%s"
                 % (min(len(raw), 60000), len(raw), strings_path, cap(raw, 60000)))
    bd = os.path.join(out, "images_" + base)
    if os.path.isdir(bd):
        text += ("\nNOTE: block diagram = images_%s\\*_reportb.png, front panel = "
                 "*_reportc.png; one PNG per case of every structure (filenames "
                 "encode the case path). Use crop_image / stitch_cases on them." % base)
    return text


def tool_list_artifacts(args):
    d = args["dir"]
    if not os.path.isdir(d):
        return "ERROR: directory not found: %s" % d
    files = walk_files(d)
    lines = ["%s  %10d  %s" % (os.path.relpath(p, d), sz,
                               __import__("datetime").datetime.fromtimestamp(m).isoformat(timespec="seconds"))
             for p, sz, m in files]
    return "directory: %s\n%d file(s)\n%s" % (d, len(files), "\n".join(lines))


def tool_crop_image(args):
    out = args.get("out") or args["src"].rsplit(".", 1)[0] + "_crop.png"
    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
           os.path.join(SCRIPTS, "crop.ps1"),
           "-Src", args["src"], "-X", str(args["x"]), "-Y", str(args["y"]),
           "-W", str(args["w"]), "-H", str(args["h"]), "-Out", out]
    if args.get("scale"):
        cmd += ["-Scale", str(args["scale"])]
    return run(cmd, timeout=120)


def tool_stitch_cases(args):
    cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File",
           os.path.join(SCRIPTS, "stitch.ps1"), "-Dir", args["dir"]]
    if args.get("name_pattern"):
        cmd += ["-NamePattern", args["name_pattern"]]
    if args.get("cols"):
        cmd += ["-Cols", str(args["cols"])]
    if args.get("rows"):
        cmd += ["-Rows", str(args["rows"])]
    res = run(cmd, timeout=180)
    return res + "\nOutput sheets are written into the same directory as sheet0.png, sheet1.png, ..."


def tool_search_docs(args):
    query = args["query"].lower()
    max_results = int(args.get("max_results", 40))
    results = []
    searched = 0
    for p, sz, _m in walk_files(HELP_DIR):
        if not p.lower().endswith((".html", ".htm")) or sz > 3_000_000:
            continue
        searched += 1
        rel = os.path.relpath(p, HELP_DIR)
        try:
            with open(p, "r", errors="replace") as f:
                content = f.read()
        except OSError:
            continue
        if query in os.path.basename(p).lower():
            results.append((rel, "[filename match] " + strip_html(
                re.sub(r"(?s).*<TITLE>(.*?)</TITLE>.*", r"\1", content) if "<TITLE>" in content else rel)))
        low = content.lower()
        pos, hits = 0, 0
        while hits < 3:
            idx = low.find(query, pos)
            if idx < 0:
                break
            snippet = strip_html(content[max(0, idx - 120): idx + 260])
            results.append((rel, snippet))
            pos = idx + len(query)
            hits += 1
            if len(results) >= max_results:
                break
        if len(results) >= max_results:
            break
    if not results:
        return "No matches for %r in %d local doc files." % (query, searched)
    body = "\n".join("%s\n    %s" % (rel, snip.replace("\n", " ")) for rel, snip in results)
    return ("Matches for %r (searched %d files, showing %d):\n\n%s\n\n"
            "Read a full page with read_doc using the relative path."
            % (query, searched, len(results), body))


def tool_search_knowledge(args):
    terms = [t.lower() for t in (args.get("query") or "").split()]
    if not terms:
        return "ERROR: empty query"
    max_results = int(args.get("max_results", 30))
    roots = [os.path.join(SKILL_ROOT, "skill-labview-code"),
             os.path.join(SKILL_ROOT, "style_codes.json")]
    files = []
    for base in roots:
        if os.path.isfile(base):
            files.append(base)
        elif os.path.isdir(base):
            for root, _dirs, names in os.walk(base):
                for n in names:
                    if n.lower().endswith((".md", ".txt")):
                        files.append(os.path.join(root, n))
    results = []
    for p in sorted(files):
        try:
            with open(p, "r", errors="replace") as f:
                lines = f.read().splitlines()
        except OSError:
            continue
        rel = os.path.relpath(p, SKILL_ROOT)
        hits = 0
        for i, ln in enumerate(lines, 1):
            low = ln.lower()
            if all(t in low for t in terms):
                results.append("%s:%d: %s" % (rel, i, ln.strip()[:200]))
                hits += 1
                if hits >= 4 or len(results) >= max_results:
                    break
        if len(results) >= max_results:
            break
    if not results:
        return ("No knowledge matches for %r. Try single keywords - the "
                "knowledge base is large; e.g. 'tunnel', '1055', "
                "'connector pane'." % args["query"])
    return ("Knowledge matches for %r (%d shown; file:line in the "
            "skill-labview-code knowledge base):\n\n%s\n\n"
            "Read the file around the given line for full context."
            % (args["query"], len(results), "\n".join(results)))


def tool_read_doc(args):
    rel = args["path"].replace("/", os.sep)
    if not rel.lower().endswith(".html"):
        rel += ".html"
    full = os.path.abspath(os.path.join(HELP_DIR, rel))
    if not full.lower().startswith(HELP_DIR.lower()):
        return "ERROR: path outside the docs mirror"
    if not os.path.isfile(full):
        return "ERROR: not found: %s" % rel
    with open(full, "r", errors="replace") as f:
        raw = f.read()
    m = re.search(r"(?i)<TITLE>(.*?)</TITLE>", raw)
    title = m.group(1).strip() if m else rel
    return "TITLE: %s\nPATH: %s\n\n%s" % (title, rel, cap(strip_html(raw), 40000))


def tool_search_ni_docs(args):
    q = urllib.parse.quote(args["query"] + " ni.com docs labview")
    url = "https://html.duckduckgo.com/html/?q=" + q
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            page = r.read().decode("utf-8", "replace")
    except Exception as e:
        return "ERROR: search failed (%s). Search engines rate-limit bots - retry later or use search_docs on the offline mirror." % e
    links = [urllib.parse.unquote(m) for m in re.findall(r'uddg=([^&"]+)', page)]
    titles = [strip_html(t) for t in re.findall(r'result__a"[^>]*>(.*?)</a>', page)]
    seen, out = set(), []
    for i, link in enumerate(links):
        if "ni.com" not in link:
            continue
        if link in seen:
            continue
        seen.add(link)
        title = titles[i] if i < len(titles) else ""
        out.append("- %s\n  %s" % (title, link))
        if len(out) >= 15:
            break
    if not out:
        return "No ni.com results (search engines rate-limit bots). Fallback: search_docs on the offline mirror, or guess the page at docs-be.ni.com/bundle/<bundle>/page/<page>.html."
    return ("ni.com results for %r:\n\n%s\n\n"
            "Fetch full page text with fetch_ni_doc (bundle = the part after "
            "/bundle/, page = the part after /page/)." % (args["query"], "\n".join(out)))


def tool_fetch_ni_doc(args):
    if args.get("url"):
        url = args["url"]
    else:
        url = "https://docs-be.ni.com/bundle/%s/page/%s.html" % (args["bundle"], args["page"])
    host = urllib.parse.urlparse(url).netloc
    if not host.endswith("ni.com"):
        return "ERROR: only ni.com hosts are allowed"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = r.read().decode("utf-8", "replace")
    except Exception as e:
        return ("ERROR: fetch failed (%s). Note: docs-be.ni.com is an UNOFFICIAL "
                "keyless backend and may be unavailable; the page may also not "
                "exist - check bundle/page spelling via search_ni_docs." % e)
    m = re.search(r"(?i)<TITLE>(.*?)</TITLE>", raw)
    title = m.group(1).strip() if m else url
    # Zoomin pages wrap the real article in <section class="section"> blocks;
    # everything outside is megabytes of navigation noise.
    sections = re.findall(r"(?is)<section\b.*?</section>", raw)
    body = "\n".join(strip_html(s) for s in sections) if sections else strip_html(raw)
    body = re.sub(r"\n{2,}", "\n", body).strip()
    return ("SOURCE: %s (unofficial keyless docs backend)\nTITLE: %s\n\n%s"
            % (url, title, cap(body, 60000)))


WRITE_VERBS = ("newvi", "place", "wire", "delete", "loop", "setval", "connector")


def _norm_path(p):
    """Normalize to a case-insensitive dir prefix with trailing sep.
    Strips a %Class|Label resolver suffix and expands %VAR%."""
    p = os.path.expandvars(p).split("%", 1)[0]
    n = os.path.normcase(os.path.abspath(os.path.expanduser(p)))
    if not n.endswith(os.sep):
        n += os.sep
    return n


def _load_allowed_paths():
    """Whitelisted directory prefixes from allowed_paths.json (a bare list
    or {"allowed_paths": [...]}). None = file missing/invalid = unrestricted
    (previous behavior)."""
    try:
        with open(ALLOWED_PATHS_FILE, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    items = data.get("allowed_paths") if isinstance(data, dict) else data
    if not isinstance(items, list):
        return None
    out = [_norm_path(p) for p in items if isinstance(p, str) and p.strip()]
    return out or None


def _path_allowed(p, allowed):
    if allowed is None:
        return True
    n = _norm_path(p)
    return any(n.startswith(a) for a in allowed)


def _guard_fail(what, p, allowed):
    return ("GUARDRAIL: %s %r is outside allowed_paths (%s). Edit "
            "allowed_paths.json next to server.py, or copy the VI into an "
            "allowed directory first (the gateway copy-first rule anyway "
            "wants user-provided VIs developed on a copy)." %
            (what, p, "; ".join(allowed)))


def tool_gateway(args):
    verb = args["verb"]
    if not os.path.isfile(GATEWAY_VI):
        return ("Gateway.vi is not built yet (%s missing). Build it once from "
                "C:\\LabView skill\\skill-labview-code\\references\\gateway-recipe.md "
                "(~10 minutes), then retry. Meanwhile use extract_vi for static "
                "VI analysis." % GATEWAY_VI)
    allowed = _load_allowed_paths()
    if allowed is not None and verb in WRITE_VERBS:
        # newvi carries the save path in arg1 (vi_path stays empty); all other
        # write verbs target vi_path (resolver suffix stripped by _norm_path).
        target = (args.get("arg1") or "") if verb == "newvi" else (args.get("vi_path") or "")
        if not target:
            return "ERROR: verb %s requires a target path" % verb
        if not _path_allowed(target, allowed):
            return _guard_fail("%s target" % verb, target, allowed)
    cmd = ["cscript", "//nologo", os.path.join(SCRIPTS, "lv_gateway.vbs"), GATEWAY_VI, verb]
    if args.get("vi_path"):
        vi = args["vi_path"]
        if verb in WRITE_VERBS:
            # Write verbs edit and save the REAL file (Save:Instrument inside
            # the Gateway). A temp copy would throw the edits away - pass the
            # path through unchanged. Targeting a VI that is open in the
            # user's LabVIEW instance is the STANDARD, supported mode: COM
            # attaches to the running instance, edits appear LIVE on screen
            # and save from the same session. Coordinate with the user -
            # two editors, one file, the user sees every change.
            cmd.append(vi)
        else:
            # vi_path may carry a reference-resolver suffix (path.vi%Class|Label);
            # only the file part exists on disk - check/copy the base, then
            # re-attach the resolver to the temp copy's name.
            base, sep, resolver = vi.partition("%")
            if not os.path.isfile(base):
                return "ERROR: vi_path not found: %s" % vi
            tmpdir = os.path.join(tempfile.gettempdir(), "lv_mcp")
            os.makedirs(tmpdir, exist_ok=True)
            dst = os.path.join(tmpdir, os.path.basename(base))
            if os.path.isfile(dst):
                os.remove(dst)
            shutil.copyfile(base, dst)
            # lvlib-member VIs break ("owning library is missing") without
            # their .lvlib sibling - copy any from the source dir (idempotent)
            for sib in glob.glob(os.path.join(os.path.dirname(base), "*.lvlib")):
                sibdst = os.path.join(tmpdir, os.path.basename(sib))
                if not os.path.isfile(sibdst):
                    try:
                        shutil.copyfile(sib, sibdst)
                    except OSError:
                        pass
            cmd.append(dst + (sep + resolver if sep else ""))
            # read verbs snapshot a temp copy for uniform behavior; this is
            # not a ban - the user's IDE-open VI works live too (getNode /
            # errors / wires attach to the running instance)
    # Slot alignment: the VBS maps argv[2]->'vi path', argv[3]->arg1, ... .
    # newvi carries its save path in arg1 and has no vi_path, so without this
    # placeholder the path would land in the 'vi path' slot and arg1 would
    # stay empty (Save:Instrument then gets an empty path -> error 43).
    if verb == "newvi" and not args.get("vi_path"):
        cmd.append("")
    for key in ("arg1", "arg2", "arg3"):
        if args.get(key):
            cmd.append(args[key])
    return run(cmd, timeout=240)


def tool_gateway_batch(args):
    """Run a SCRIPT of gateway commands in ONE LabVIEW session.

    Script format: one command per line, fields ';'-separated:
      verb;vi_path;arg1;arg2;arg3      (trailing fields optional)
      !verb;...                       failure tolerated, keep going
      # comment / delete;<path> / copy;<src>;<dst> / echo;<text> / sleep;<ms>
    Stops at the first failing command unless the line starts with '!'.
    Tip for retries: prefer a FRESH vi name per attempt (newvi) over
    delete+recreate - the LabVIEW instance keeps deleted VIs in memory
    under their old name.
    """
    if not os.path.isfile(GATEWAY_VI):
        return ("Gateway.vi is not built yet (%s missing). Build it once from "
                "C:\\LabView skill\\skill-labview-code\\references\\gateway-recipe.md "
                "(~10 minutes)." % GATEWAY_VI)
    script = args.get("script") or ""
    if not script.strip():
        return "ERROR: empty script"
    allowed = _load_allowed_paths()
    if allowed is not None:
        # Scan every line the batch runner would act on: write-verb vi_path
        # fields, newvi arg1 save paths, and the script-level 'delete;<path>'
        # and 'copy;<src>;<dst>' meta-lines (real FILE operations).
        violations = []
        for ln in script.splitlines():
            s = ln.strip()
            if not s or s.startswith("#"):
                continue
            if s.startswith("!"):
                s = s[1:]
            low = s.lower()
            if low.startswith("delete;"):
                p = s.split(";", 1)[1].strip()
                if p and not _path_allowed(p, allowed):
                    violations.append(ln)
                continue
            if low.startswith("copy;"):
                parts = s.split(";")
                if len(parts) >= 3 and parts[2].strip() and \
                        not _path_allowed(parts[2].strip(), allowed):
                    violations.append(ln)
                continue
            parts = s.split(";")
            if parts and parts[0].strip().lower() in WRITE_VERBS:
                verb = parts[0].strip().lower()
                idx = 2 if verb == "newvi" else 1  # newvi: arg1 = save path
                if len(parts) > idx:
                    target = parts[idx].strip()
                    if target and not _path_allowed(target, allowed):
                        violations.append(ln)
        if violations:
            return ("GUARDRAIL: script touches paths outside allowed_paths "
                    "(%s) - refused:\n%s" % ("; ".join(allowed),
                                             "\n".join(violations)))
    tmpdir = os.path.join(tempfile.gettempdir(), "lv_mcp")
    os.makedirs(tmpdir, exist_ok=True)
    script_path = os.path.join(tmpdir, "batch_script.txt")
    with open(script_path, "w", encoding="ascii", errors="replace") as f:
        f.write(script.replace("\r\n", "\n") + "\n")
    timeout = int(args.get("timeout_s") or 600)
    cmd = ["cscript", "//nologo", os.path.join(SCRIPTS, "lv_gateway_batch.vbs"),
           GATEWAY_VI, script_path]
    return run(cmd, timeout=timeout)


def tool_arrread(args):
    """Universal FP control/indicator value I/O via the arrread.exe C# helper
    (revised 2026-10-20): sets/reads ALL types - numerics of any representation,
    strings, booleans, 1D/2D arrays (typed variant arrays), clusters (array of
    variants). 'cycle' = set+echo+run+poll-read in ONE process (the only reliable
    mode; separate-process set/get hits the cross-process persistence trap).
    'values' grammar: bare number = double scalar; bare comma-list = double[];
    typed prefixes dbl: sgl: i8..i64 u8..u64 s: b: a: ai: as: ab: ad:
    a2:[[1,2],[3,4]] ai2: au8: ... ; cluster: c:(1,s:hi,b:true,ai:[1,2]).
    """
    mode = args["mode"]
    vi = args["vi_path"]
    ctl = args["control"]
    values = args.get("values") or ""
    outctl = args.get("outctl") or ""
    if not os.path.isfile(ARRREAD_EXE):
        return ("ERROR: arrread.exe not found at %s - see " % ARRREAD_EXE +
                "C:\\LabView skill\\skill-labview-code\\references\\"
                "gateway-recipe.md (runtime verification section)")
    if mode in ("set", "setint", "cycle") and not values:
        return "ERROR: mode %s requires 'values'" % mode
    cmd = [ARRREAD_EXE, mode, vi, ctl]
    if values:
        cmd.append(values)
    if outctl:
        cmd.append(outctl)
    return run(cmd, timeout=180)


def tool_getval(args):
    """Read any BD/FP element value via Gateway getval + lv_flat decode.

    vi_path is a full item identifier 'X.vi%Class|Label'. The gateway flattens
    the element (Variant To Flattened String) and returns the type descriptor
    as an I16 CSV plus the data string HEX-encoded (v3.30; lossless over COM -
    the old raw-BSTR transport mangled bytes >= 0x80).
    """
    selector = args.get("vi_path") or ""
    if not os.path.isfile(GATEWAY_VI):
        return ("ERROR: Gateway.vi missing (%s) - getval needs the gateway" % GATEWAY_VI)
    base = selector.split("%")[0].split("|")[0]   # strip resolver AND |BD/|FP target
    if not os.path.isfile(base):
        return "ERROR: vi_path not found: %s" % selector
    if "%" not in selector:
        return ("ERROR: vi_path must be '<abs .vi path>%<ResolverClass>|<Label>' "
                "(full item identifier), e.g. 'C:cvx.vi%DigitalNumericConstant|N'")
    out = run(["cscript", "//nologo", os.path.join(SCRIPTS, "lv_getval_hex.vbs"),
               GATEWAY_VI, selector], timeout=240)
    typ = dhex = None
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("TYPE="):
            typ = line[5:].strip()
        elif line.startswith("DATA_HEX="):
            dhex = line[9:].strip().lower()
    if not typ or not dhex:
        return "getval failed: " + out.strip()
    spec = importlib.util.spec_from_file_location(
        "lv_flat", os.path.join(SCRIPTS, "lv_flat.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    try:
        td, _ = mod.parse_td(mod.i16_bytes(typ), 0)
        data = bytes.fromhex(dhex)
        v, off = mod.dec_data(td, data, 0)
    except Exception as e:
        return ("decode failed (%s)\nTYPE=%s\nDATA_HEX=%s" % (e, typ, dhex))
    return "%s = %s\n[%s]\n(%d of %d data bytes consumed)" % (
        td.name or td.kind(), mod.fmt(v), td.tree().replace("\n", "; "),
        off, len(data))


def tool_lva_worker(args):
    """Drive ONE Scripting Server 2020 worker VI via COM (lva_worker.vbs)."""
    if not os.path.isfile(LVA_WORKER_VBS):
        return "ERROR: %s not found" % LVA_WORKER_VBS
    worker = (args.get("worker_path") or "").strip()
    if not worker:
        return "ERROR: worker_path required (e.g. %s\\Do Get Open VIs.vi)" % LVA_WORKERS
    if not os.path.isabs(worker) or not os.path.isfile(worker):
        cand = os.path.join(LVA_WORKERS, worker)
        cand2 = cand if cand.endswith(".vi") else cand + ".vi"
        if os.path.isfile(cand2):
            worker = cand2
        elif os.path.isfile(cand):
            worker = cand
        else:
            return ("ERROR: worker VI not found: %s (and not in %s)" %
                    (worker, LVA_WORKERS))
    # 32-bit cscript -> attaches to / launches the background 32-bit LV2020
    # that owns the LV2020-format worker VIs (COM instance map, see KB).
    cscript = r"C:\Windows\SysWOW64\cscript.exe"
    if not os.path.isfile(cscript):
        cscript = "cscript"
    cmd = [cscript, "//nologo", LVA_WORKER_VBS, worker]
    for s in (args.get("set") or []):
        cmd.append(str(s))
    for r in (args.get("read") or []):
        cmd.append("--read=%s" % r)
    sleep_ms = int(args.get("sleep_ms") or 0)
    if sleep_ms:
        cmd.append("--sleep=%d" % sleep_ms)
    else:
        cmd.append("--sleep=12000")
    return run(cmd, timeout=240)


def tool_lva_session(args):
    """Persistent-session call to the LVA Session server (gateway\\LVA\\LVA Session.vi)
    via lva_call.vbs. Session state (Data Cluster vi_id registry) survives
    between calls - a keeper process (lva_keeper.vbs) holds the COM reference
    so the COM-launched LabVIEW never quits between calls. Request goes in via
    COM SetControlValue, reply comes back via file (GetControlValue is stale
    during a run). Verified end-to-end 2026-10-27: open_vi -> vi_id, save_vi
    -> file on disk, vi_id registry persists (open A -> 1, open B -> 2)."""
    if not os.path.isfile(LVA_CALL_VBS):
        return "ERROR: %s not found" % LVA_CALL_VBS
    tool = (args.get("tool") or "").strip()
    if tool not in ("open_vi", "save_vi"):
        return "ERROR: tool must be open_vi or save_vi (got %r)" % tool
    cmd = [CSCRIPT, "//nologo", LVA_CALL_VBS, tool]
    if tool == "open_vi":
        p = (args.get("vi_path") or "").strip()
        if not p:
            return "ERROR: vi_path required for open_vi"
        cmd.append(p)
    else:
        vid = args.get("vi_id")
        sp = (args.get("save_path") or "").strip()
        if vid is None or not sp:
            return "ERROR: vi_id and save_path required for save_vi"
        cmd.append(str(int(vid)))
        cmd.append(sp)
    return run(cmd, timeout=240)


def tool_lv_guidance(args):
    """Static best-practice guidance: documentation access, patterns, guardrails."""
    return (
        "LABVIEW CODEGEN GUIDANCE (fixed text)\n"
        "\n"
        "1) DOCUMENTATION ACCESS\n"
        "- Function/property semantics, terminal orders, design patterns: "
        "search_docs -> read_doc (offline CHM mirror; no network, always "
        "works). Key pages: glang/<Function>.html (terminal-order image), "
        "lvhowto/creating_vis_from_templates.html and "
        "lvconcepts/Examples_and_VI_Templates.html (patterns incl. state "
        "machine), lvconcepts/Block_Diagram_Objects.html.\n"
        "- ni.com pages are JS shells; use search_ni_docs + fetch_ni_doc "
        "(docs-be backend) only as fallback.\n"
        "- vi.lib/llb subVIs: extract_vi the POLYMORPHIC PARENT - its "
        "_strings.txt names HELP_PATH/HELP_TAG -> find that page in the "
        "mirror (verified on Linear Fit, 6fits.llb).\n"
        "- Structured verified facts (terminal maps, pane cells, wire "
        "kinds, rep codes): lv_reference. Prose knowledge base: "
        "search_knowledge.\n"
        "\n"
        "2) PROGRAMMING PATTERNS\n"
        "- State machine: enum state in a shift register + Case structure "
        "on the enum (event-driven variant: Event structure + state "
        "machine, see loc_bd_typicaleventstatemach.gif). Preferred for any "
        "multi-step task.\n"
        "- Producer/consumer: queues (Obtain Queue), producer loop "
        "acquires, consumer processes; dequeue timeout for shutdown.\n"
        "- Error handling: error in/out clusters through EVERY subVI; "
        "merge errors at joins; fail fast on Error, warn continues.\n"
        "- SubVIs: connector pane 4-2-2-4, controls left/top, indicators "
        "right/bottom, no front-panel clutter; every control a terminal.\n"
        "- Initialization: define defaults (Edit > Make Current Value "
        "Default); an uninitialized shift register KEEPS state between "
        "runs.\n"
        "\n"
        "3) CODEGEN GUARDRAILS (verified rules)\n"
        "- Work on a COPY; apply to the original only after verification.\n"
        "- 'wire ok' != connected: check wires (broken flags) + errors "
        "verb (empty = clean) after every edit batch.\n"
        "- Array wires crossing loop borders auto-create Auto-Index "
        "tunnels - set them Regular (tunnel:i;0) or the wire stays broken.\n"
        "- FP objects need x,y,W,H (W,H = FP item size); 0-size = unreadable.\n"
        "- Growable nodes (Case/Stacked structures, Bundles) need W,H too.\n"
        "- Before wiring from memory, query lv_reference (Feedback Node "
        "terminal map is RANDOM per instance!).\n"
    )


def tool_lv_reference(args):
    """Structured lookup over the verified codegen facts (lv_knowledge.json):
    primitive/structure terminal maps, subVI connector panes, wire kinds,
    resolver classes, setval representation codes, error-code meanings."""
    spec = importlib.util.spec_from_file_location(
        "lv_knowledge", os.path.join(SCRIPTS, "lv_knowledge.py"))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    db = mod.load()
    words = [w for w in (args.get("query") or "").split() if w]
    results = mod.search(db, words)
    if not results:
        return ("no match for: %s (try fewer/shorter words, or the full-text "
                "search_knowledge tool over the prose docs)" % (args.get("query") or ""))
    lines = []
    for title, blob, src, note in results[:15]:
        lines.append(title)
        if note:
            lines.append("  note: %s" % note)
        if src:
            lines.append("  verified: %s" % src)
    if len(results) > 15:
        lines.append("(+%d more matches - refine the query)" % (len(results) - 15))
    return "\n".join(lines)


def tool_manage_processes(args):
    action = args["action"]
    if action == "list":
        return run(["powershell", "-NoProfile", "-Command",
                    "Get-CimInstance Win32_Process -Filter \"Name='LabVIEW.exe'\" "
                    "| Select-Object ProcessId,ExecutablePath | Format-List"])
    if action == "kill":
        pid = args.get("pid")
        if not pid:
            return "ERROR: kill requires pid (run action=list first)"
        return run(["powershell", "-NoProfile", "-Command",
                    "Stop-Process -Id %s -Force" % int(pid)])
    return "ERROR: action must be 'list' or 'kill'"


# --------------------------------------------------------------------------
# Tool metadata
# --------------------------------------------------------------------------

TOOLS = [
    {
        "name": "extract_vi",
        "description": (
            "Extract a LabVIEW .vi's code into analyzable artifacts: a strings "
            "export (every control, constant value, function name), an HTML "
            "report, and PNGs of the front panel, block diagram, and every case "
            "of every structure. Works on a copy - the original is never "
            "touched. PRIMARY tool for 'view VI code / pseudocode / explain "
            "this VI / talk with a VI' when a file path is known. Returns "
            "artifact paths plus a preview of the strings export. The first "
            "call in a session spawns a background LabVIEW (may take ~1 min)."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "vi_path": {"type": "string", "description": "Absolute path of the .vi file"},
                "out_dir": {"type": "string", "description": "Output directory (default: C:\\LabView skill\\_service\\extract\\<vi name> - a gitignored service area)"}
            },
            "required": ["vi_path"]
        }
    },
    {
        "name": "list_artifacts",
        "description": "List files (relative path, size, modified) in an extraction output directory.",
        "inputSchema": {
            "type": "object",
            "properties": {"dir": {"type": "string", "description": "Directory to list"}},
            "required": ["dir"]
        }
    },
    {
        "name": "crop_image",
        "description": "Crop and upscale a region of an extracted diagram PNG (nearest-neighbor, default 3x) so labels, constants and terminal wiring become readable.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "src": {"type": "string"}, "x": {"type": "integer"}, "y": {"type": "integer"},
                "w": {"type": "integer"}, "h": {"type": "integer"},
                "out": {"type": "string"}, "scale": {"type": "integer", "description": "default 3"}
            },
            "required": ["src", "x", "y", "w", "h"]
        }
    },
    {
        "name": "stitch_cases",
        "description": "Stitch per-case PNGs of a Case/Event structure into numbered contact sheets (sheet0.png, sheet1.png, ...) in the same directory, so every case can be reviewed at once. Filter with name_pattern (regex on the file base name).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "dir": {"type": "string"},
                "name_pattern": {"type": "string"},
                "cols": {"type": "integer"}, "rows": {"type": "integer"}
            },
            "required": ["dir"]
        }
    },
    {
        "name": "search_docs",
        "description": (
            "Full-text search over the OFFLINE mirror of the LabVIEW 2020 CHM "
            "documentation (function reference 'glang', properties 'lvprop', "
            "how-to 'lvhowto', concepts 'lvconcepts', scripting 'lvscript). "
            "Best first stop for 'what does function X do', terminal orders, "
            "property semantics, design patterns and VI templates (e.g. "
            "'creating_vis_from_templates', 'Examples_and_VI_Templates')."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "max_results": {"type": "integer"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "read_doc",
        "description": "Read one page from the offline LabVIEW docs mirror as plain text. Path is relative to the help root, e.g. 'glang/Select.html' or 'TRef_Traverse_for_References.html'. Get paths from search_docs.",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"]
        }
    },
    {
        "name": "search_ni_docs",
        "description": (
            "Web-search for ni.com LabVIEW documentation pages about a function "
            "or topic; returns candidate URLs. Rate-limited (bot detection) - "
            "use sparingly; prefer search_docs first. Follow up with "
            "fetch_ni_doc using the bundle/page parts of the URL."),
        "inputSchema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"]
        }
    },
    {
        "name": "fetch_ni_doc",
        "description": (
            "Fetch a live ni.com LabVIEW documentation page as plain text from "
            "NI's UNOFFICIAL keyless docs backend "
            "(https://docs-be.ni.com/bundle/<bundle>/page/<page>.html). May "
            "break at any time; the offline mirror (search_docs/read_doc) is "
            "the reliable fallback."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "bundle": {"type": "string", "description": "e.g. 'labview'"},
                "page": {"type": "string", "description": "e.g. 'mcp-server-nigel'"},
                "url": {"type": "string", "description": "Full ni.com URL (alternative to bundle/page)"}
            },
            "required": []
        }
    },
    {
        "name": "gateway",
        "description": (
            "Run the Gateway.vi helper (v3.12) inside LabVIEW via COM/VI "
            "Scripting. STRICT RULE for user-provided VIs: never run write "
            "verbs (newvi/place/wire/delete/loop/setval) directly on the user's "
            "original VI. Copy it first (e.g. <name>_tmp.vi), develop and "
            "debug the script on the copy, verify it (wires: zero "
            "broken:1, plus a runtime value check), and only then apply "
            "the proven script to the original. Read verbs (ping/analyze/"
            "wires/listmem/errors) are safe on the original. "
            "Read verbs: ping (sanity check), analyze (one line "
            "per block-diagram object: index, ClassName, label, UID; "
            "arg1='FP' lists FRONT-PANEL objects instead (ClassName like "
            "'Digital', label, FP-element UID - these are the UIDs the "
            "connector verb's U: form needs)), wires (one "
            "line per wire: label, broken flag, UID, terminals as "
            "'Label(UID) [OwnerClass] of Node{ UID, Label}' - the terminal's "
            "label+UID and its owning node's UID+Label; source first, then "
            "all sinks separated by ';'; combined with analyze + getNode "
            "this restores the block diagram completely), "
            "listmem, errors (v3.14: returns the IDE Error-List "
            "content for the VI - 'Errors list = <msg>;<msg>;' 'Details = "
            "<details>;<details>;' - items and details are ';'-separated "
            "and index-aligned; EMPTY Errors list = VI is clean; the item "
            "text does NOT name the offending object, pair it with "
            "analyze/wires to locate it), getNode (v3.17: arg1='terms'. "
            "vi_path='%Node|<label>' -> per-terminal lines 'Term[i] UID, "
            "name, isSource, isHidden, wireUID/wireBroken | No wire "
            "connected'; vi_path=a .vi/.llb path -> the subVI's "
            "connector-pane 'Control[i]: UID, Label, Indicator, "
            "IsOnConPanel, Wiring rule' - read the interface BEFORE wiring "
            "instead of probing; FN terminals have empty names and the "
            "source flag does not reveal which sink is init vs input), "
            "analyze/wires to locate it). Write verbs (edit and SAVE the real file; if the user's "
            "LabVIEW is running, COM attaches to that instance and the edit "
            "appears LIVE in the open VI - safe and preferred; if edits do "
            "not appear live, a background instance was used and an IDE-open "
            "copy is stale: user must reload from disk before saving): newvi "
            "(arg1=full save path; vi_path stays EMPTY), place (vi_path="
            "target VI or resolver, arg1=type e.g. Add|Multiply|Numeric "
            "Control|String Constant, arg2='x,y' diagram location (or "
            "'x,y,W,H': W,H REQUIRED for growable nodes and for FP objects - "
            "it is the FRONT-PANEL ITEM SIZE; 0 makes the item unreadable "
            "on the FP), arg3="
            "label or '-'; returns UID). v3.12: FRONT-PANEL OBJECTS "
            "(numind/numctl/any:21003/any:21004/...) ARE placeable INSIDE "
            "structures via resolver - the gateway creates the FP object "
            "and moves its terminal into the loop diagram automatically "
            "(verified: any:21004 and any:21003; the terminal is then a "
            "normal c|0 terminal wireable to nodes inside). arg2 for ANY "
            "front-panel object (numctl/numind/strctl/strind, any:21003/"
            "21004/21607/21703) MUST be 'x,y,W,H' - W,H is the FP item "
            "size; use 80,32 for numeric ctl/ind, 400,300 for a graph; "
            "without W,H the FP item is 0-size and UNREADABLE for the user "
            "(run tests do NOT catch it - the batch runner warns). "
            "delete (v3.12): vi_path = resolver of the container structure "
            "(objects inside it) or plain VI path (top-level objects); "
            "arg1 = class name ('GObject' matches any object, 'Wire' for "
            "wires); arg2 = 'U:<uid>' or 'L:<label>'. Saves automatically. "
            "CAUTION: in gateway_batch scripts a 2-field line "
            "'delete;<path>' is the script-level FILE delete, not this "
            "verb (3+ field lines go to the gateway). "
            "loop (vi_path='path.vi%ForLoop|"
            "Label', arg1='addSR', arg2=Y position, arg3=Label; returns "
            "UID. v3.8 TUNNEL CONTROL: arg1='tunnel:<idx>' or "
            "'tunnel:U<uid>' (from the -1 status query), arg2=-2 = tunnel "
            "count, arg2=-1 = status ('Tunnel[0], IndexMode: 0, UID=..'), "
            "arg2 0/1/2 sets IndexMode (0=regular, 1=auto-index, "
            "2=concatenate). arg1='addSR', arg2=Y position, arg3=Label adds "
            "a SHIFT REGISTER to the loop (returns 'NewShiftReg, UID='; the "
            "SR must exist before wiring s* terminals - see wire arg2). "
            "TRAP: border auto-tunnels are created "
            "Auto-Index - always 'tunnel:i;0' array crossings or arrays "
            "scalarize element-wise), setval (vi_path='path.vi[|BD|FP]%Class|Label' "
            "resolver to the element - Class is a SHORT name without spaces, "
            "e.g. 'NumericConstant', 'ClusterConstant'; generic 'Constant' "
            "also works; the verbose analyze ClassName does NOT - wrong class "
            "gives ERROR 1092; optional |BD (default) or |FP selects the "
            "target hierarchy (v3.31 resolver searches BD first, then FP). "
            "Works on BD constants AND FP controls. arg1=value, arg2=type: "
            "dec|frc|str|bool|XML (XML = full getval reply: <Cluster> with "
            "type-string I16 array + HEX data string; sets ANY type incl. "
            "clusters - verified on BD constants AND FP controls). "
            "PERSISTENCE: FP-control values are RUNTIME-ONLY, not saved "
            "with the VI - visible in the live instance/IDE, lost on close "
            "or in a separate instance; getval on a control reads the "
            "DEFAULT, and cross-process arrread get is stale (the known "
            "GetControlValue trap) - the only reliable set+run+read loop "
            "is the arrread tool's 'cycle' mode; use setval on FP controls "
            "for live co-editing (value visible in the open IDE VI). "
            "arg3 = numeric representation code, "
            "numerical targets only, empty = keep: 0 EXT, 1 DBL, 2 SGL, "
            "3 I32, 4 I16, 5 I8, 6 U32, 7 U16, 8 U8, 9 CEXT, 10 CDB, "
            "11 CSG, 12 I64, 13 U64, 14 FXF - changes rep AND value in one "
            "call (v3.31, rep first then value; verified I32->DBL 3.5 and "
            "DBL->I32 42 on CodeC). WARNING: a placed numeric constant "
            "(numconst/any:2005) is I32 integer - 'frc' on it SILENTLY "
            "writes 0 and 'dec' truncates; setval integers only or change "
            "the representation via arg3 first, build fractional math from "
            "DBL node outputs instead), wire (vi_path="
            "target VI, arg1='srcLabel|dstLabel', arg2='srcKind|srcIdx|"
            "dstKind|dstIdx' where kind c=control/constant terminal (c|0), "
            "n=Terms[] index of a node - ForLoop has ONLY n|0=N; kind i=loop "
            "counter terminal: arg1's source label is the LOOP's label (e.g. "
            "wire 'Loop1|Add1' 'i|0|n|2' wires Loop1's i to Add.x). The wire "
            "RESPONSE reports both terminals with isSource flags and Name: "
            "legal wire = src isSource:1 AND dst isSource:0; 1/1 = "
            "output-output, 0/0 = input-input (both broken:1). 'wire ok' = "
            "created, not legal - read the flags. "
            "connector (vi_path=plain VI path, arg1 EMPTY, arg2='L:<FP "
            "control label>' or 'U:<FP-element UID>' - the UID getNode Mode "
            "B reports, NOT the block-diagram terminal UID - or "
            "'disconnect', arg3=0-based pane cell index): assigns/dismisses "
            "connector-pane terminals, making newvi-created VIs fully "
            "usable subVIs (verified end-to-end: pane cell = subVI Terms[] "
            "index). Reconnecting a control to another cell RELOCATES it. "
            "place arg1 types: the small named set (Add, Numeric Constant, "
            "...) or 'any:<styleCode>' for anything else (Feedback Node = "
            "any:2353; codes in C:\\LabView skill\\style_codes.json). "
            "SUBVIs (vi.lib / .llb members shipped with the IDE): arg1 = "
            "'any:0<full path>' places the file at <path> (the 0 is "
            "literal). SubVI terminals are indexed by CONNECTOR-PANE CELL "
            "NUMBER (Context Help numbering), NOT inputs-first - wiring an "
            "empty cell gives broken:1 with empty Name; primitives are the "
            "opposite (output-first). Learn the interface with getNode on "
            "the subVI path + lv_extract2.vbs strings BEFORE wiring; "
            "verified pane tables and gotchas: references/subvi-placement.md "
            "in the skill-labview-code knowledge base. " 
            "FEEDBACK NODE TERMINAL ORDER IS RANDOM PER INSTANCE - always "
            "determine it per FN (2026-10-19: two gateway-placed FNs in one "
            "session were both Map A, refuting the creation-path theory; "
            "earlier gateway-placed FNs were Map B). Procedure: getNode "
            "'<vi>%Node|<fnlabel>' terms - the terminal with isSource:1 is "
            "the OUTPUT; source=[0] -> Map B ([0]=out,[1]=init,[2]=in); "
            "source=[1] -> Map A ([0]=in,[1]=out,[2]=init). Both sinks "
            "accept wires, so init-vs-input follows from the rotation once "
            "the source index is known; if source=[2], run-test. If "
            "already wired wrong, delete (delete;vi;Wire;U:<uid> from the "
            "wires output) and rewire. "
            "BORDER RULE: any wire crossing a loop border auto-creates an "
            "Auto-Index tunnel - the tunnel segment reads broken:1 until "
            "you set it Regular (loop verb, tunnel:i;0). This includes "
            "NODE outputs: after the last border-crossing wire, set ALL "
            "tunnels Regular (tunnel:0;-2 for count, then tunnel:i;0) and "
            "verify with wires (zero broken:1). Never re-invoke a failed "
            "wire (second tunnel pollutes the VI - use a fresh name); "
            "constants may cross (tunnel inherits the label). Tap the Add "
            "output for the result, NOT the Feedback Node output (FN lags "
            "one cycle). Run-verify via "
            "references\\run_vi_get_value.vbs (GetControlValue, VBScript "
            "only). RESOLVER: vi_path may "
            "carry 'C:\\...\\file.vi%Class|Label' or nested "
            "'%Class|Label%Class|Label' suffixes to target an element "
            "inside a structure (used by place/loop/setval). analyze/wires "
            "copy the target to temp; write verbs do not. Recipe: "
            "C:\\LabView skill\\skill-labview-code\\references\\"
            "gateway-recipe.md. COMPOSITE HELPERS in mcp-labview/scripts "
            "(prefer for frequent actions): lv_loop_scaffold (loop+N+SR "
            "one-shot), lv_fn_wire (FN map detection + wiring), "
            "lv_tunnels_regular, lv_verify (wires+errors+compile check - "
            "the IDE error list is computed LAZILY, so errors alone can "
            "give a false PASS), lv_runcheck (copy-first run+read)."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "verb": {"type": "string", "enum": ["ping", "analyze", "listmem", "wires", "getNode", "errors", "newvi", "place", "wire", "delete", "loop", "setval", "connector", "BD", "case", "GenCCodeVariant", "CompileToDFIRCPP"], "description": "Read verbs (incl. getNode = terminal/connector-pane info, errors = IDE Error-List content, empty = clean) copy the target to temp; write verbs (newvi/place/wire/delete/loop/setval/connector/BD) edit and save the real file; 'case' reads/edits case-structure frames (getFrames / setFrameNames / addFrame / delFrame); 'GenCCodeVariant' generates C code from the VI hierarchy (EXPERIMENTAL - requires the discontinued NI LabVIEW C Code Generator module; without it it always returns ERROR 1043); 'CompileToDFIRCPP' exports the VI block diagram as a C++ DFIR reconstruction program (semantic export: nodes, values, wires)"},
                "vi_path": {"type": "string", "description": "Target VI, optionally with %Class|Label resolver suffix (place/loop/setval). For newvi leave empty"},
                "arg1": {"type": "string", "description": "newvi: save path. place: object type. delete: class name ('GObject' works for any object, 'Wire' for wires). loop: 'addSR' or 'tunnel:<idx>'/'tunnel:U<uid>'. setval: value. wire: 'srcLabel|dstLabel'. getNode: 'terms' (only mode supported). analyze: 'FP' for front-panel objects (optional; both variants return 'POS: x,y; AREA: w,h' for EVERY listed GObject - FP objects when 'FP', BD node positions otherwise; AREA is the node bounds, useful for structures like loop bounds). BD: block-diagram action - 'CleanUp' or 'RemWireLooseEnds' (no further args); 'CreateConstFromDataType' or 'CreateFromDataType' (see arg2/arg3). case: 'getFrames' - vi_path must resolve a CASE STRUCTURE ('<vi>%GObject|<case label>'); returns 'UID: <n>;Frames: <k>' plus one 'Frame[i]: UID: <diagram UID>; Name: <case name>' line per frame (non-case GObject -> ERROR 1057; unknown label -> 'Not found'). case: 'setFrameNames' - arg2 = XML in the EXACT getval-reply envelope (see arg2) with a 1D STRING ARRAY: the type-string I16 array is FIXED for any 1D string array (26,16448,1,-1,-1,8,48,-1,-1,1875,29810,16754,29233 - embedded name is ignored); data hex = I32 count, then per name I32 length + ASCII bytes (big-endian). GENERATE the payload with 'python mcp-labview/scripts/lv_frame_names_xml.py <name1> <name2> ...' (prints the single-line XML; uses lv_flat.py wrap internally) instead of hand-building it; names must match the selector type (string names on a numeric case break the VI) and count must equal the frame count (mismatch -> ERROR 1302, no change). case: 'addFrame' - arg2 = '<refFrameIndex>,<after 0|1>' (plain, no quotes); inserts a new frame after (after=1) or before (after=0) the reference frame; new frame gets the next free numeric name; returns 'OK UID: <new frame Diagram UID>'. case: 'delFrame' - arg2 = 0-based frame index; deletes that frame, returns 'OK'; refuses to delete the ONLY frame (ERROR 1 Remove Frame); deleting the Default frame breaks the VI - check errors / re-designate via setFrameNames. FRAME INDICES ARE POSITIONAL AND SHIFT after add/del - re-run getFrames before further frame operations, and run errors afterwards to confirm the VI is still clean. GenCCodeVariant: arg1 = XML envelope (lv_flat.py wrap) holding the Config Params variant (name/value codegen attributes - exact type undocumented); EXPERIMENTAL: the underlying VI:Generate C Code Variant method needs the discontinued NI LabVIEW C Code Generator module, which is NOT installed - every call returns ERROR 1043 (method not supported in this LabVIEW) regardless of config; verb kept for future experimentation. CompileToDFIRCPP: arg1 = VIVariableName (C identifier prefix used in the generated TestVI_data array and DFIR::VirtualInstrument variable); the VI must be CLEAN/COMPILABLE (broken VI -> ERROR 1000 'not in a state compatible'); the RESULT is a complete C++ program (DFIR::TestUtil format) that reconstructs the VI: flattened values in TestVI_data, node Create calls with SetSourceID(<UID> = same UIDs analyze reports), nested diagram blocks and NodeConnectionSpecification connectivity - a semantic BD dump; use for VI documentation/diffing; parse the result with 'python mcp-labview/scripts/lv_dfir.py <file.cpp> [-o out.json]' for structured JSON (nodes with UIDs + decoded values, diagram tree, connections)"},
                "arg2": {"type": "string", "description": "place: 'x,y' or 'x,y,W,H' (W,H REQUIRED for growable nodes AND for FP objects - it is the FRONT-PANEL ITEM SIZE; 0 makes the item 0-size/unreadable on the FP). delete: 'U:<uid>' or 'L:<label>' (UIDs come from analyze/wires). loop: Y position, or for tunnel: arg1: -2=count, -1=status, 0/1/2=set IndexMode. setval: dec|frc|str|bool|XML (XML = a full getval reply: <Cluster> with type-string I16 array + HEX data string; sets ANY type incl. clusters - verified on BD constants AND FP controls; BUILD it reliably with 'python mcp-labview/scripts/lv_flat.py encode <typecsv> <expr>' + 'lv_flat.py wrap <typecsv> <datahex>' - the type csv comes from a getval of any constant of the wanted type). BD Create*: XML formatted data type in the SAME setVal:XML format (build with lv_flat.py encode+wrap; NOTE the created constant gets the TYPE only - the data hex is IGNORED, default value 0.0/empty; set the value afterwards with setval XML on the created constant's label); the created object is MOVED to the requested position after creation (GObject.Move) - if vi_path resolves an owner ('%GObject|<structure label>', same mechanism as place), the object is moved INSIDE it and x,y are relative to the owner's origin. wire: 'srcKind|srcIdx|dstKind|dstIdx'. connector: 'L:<FP control label>' or 'U:<FP-element UID>' (from getNode Mode B - NOT the block-diagram terminal UID) or 'disconnect'. SHIFT REGISTERS: kind 's'+l|r+i|o+input# (slo=left outside INOUT/init-sink, sli=left inside OUTPUT, sri=right inside INOUT, sro=right outside OUTPUT); the IDX FIELD after '|' = which SR (0-based addSR order). Regular SRs: input# always 0 (sli1 = multi-input SR input #1 -> ERROR 1055). SR must pre-exist: create with loop addSR first. Ex: 'c|0|slo0|0' wires a control to SR0 init; 'sro0|0|c|0' wires SR0 final value out. Other kinds: c=terminal c|0, n=Terms[] index (ForLoop only n|0=N), i=loop counter, st%d=WhileLoop STOP terminal ('st1|0'=stop-if-true setting 1 - trailing |0 ignored; accepts Boolean or error cluster, but an error cluster forces stop-on-error regardless of the setting; source inside the loop wires directly, outside auto-tunnels)."},
                "arg3": {"type": "string", "description": "place: label ('-' = none). loop: label. delete: unused. connector: 0-based connector-pane cell index (Control[i]; cell 0 is usable). BD Create*: 'x,y,Label' - horizontal pos, vertical pos, label of the created element; returns 'UID: <n>' of the created element; x,y are absolute on the target diagram, or relative to the owner's origin when vi_path resolves a structure (see arg2). CompileToDFIRCPP: arg2 = IndentationLevel (integer; adds that many tabs to every output line; 0 = the method's own formatting)"}
            },
            "required": ["verb"]
        }
    },
    {
        "name": "gateway_batch",
        "description": (
            "Run a SCRIPT of gateway commands in ONE LabVIEW session (much "
            "faster than one-by-one gateway calls; one COM attach, N verbs). "
            "Script = newline-separated commands, fields ';'-separated: "
            "'verb;vi_path;arg1;arg2;arg3' (trailing fields optional; empty "
            "field = empty arg). Meta-lines: '# comment', '!verb;...' (failure "
            "tolerated, keep going), 'delete;<path>', 'copy;<src>;<dst>' "
            "(fresh-name wires/analyze checks), 'echo;<text>', 'sleep;<ms>'. "
            "Stops at the first failing gateway command (result starts with "
            "ERROR) unless the line is prefixed '!'. Output: 'LINE <n> "
            "[<verb>]: <result>' per command. RETRY TIP: prefer a FRESH vi "
            "name per attempt (newvi bubble1.vi, bubble2.vi, ...) over "
            "delete+recreate - the LabVIEW instance keeps deleted VIs in "
            "memory under their old name, which confuses later reads. All "
            "gateway verb semantics apply unchanged (see the gateway tool). "
            "STRICT RULE for user-provided VIs: develop/debug the whole "
            "script on a COPY of the VI first; apply to the original only "
            "after the copy verifies clean (zero broken wires + runtime "
            "check). Prefer a FRESH newvi name per retry over deleting."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "script": {"type": "string", "description": "The script text, one command per line"},
                "timeout_s": {"type": "integer", "description": "Overall timeout, default 600"}
            },
            "required": ["script"]
        }
    },
    {
        "name": "arrread",
        "description": (
            "Universal front-panel value I/O on a SAVED .vi (revised "
            "2026-10-20): set/read controls and indicators of ALL types - "
            "numerics of any representation (U8..U64, I8..I64, SGL, DBL), "
            "strings, booleans, 1D/2D arrays (typed variant arrays), and "
            "clusters (array of variants, mixed element types). Modes: 'get' "
            "(print value + actual variant type), 'set' (typed value grammar), "
            "'setint' (legacy alias for ai:), 'run', 'cycle' (set + echo + run "
            "+ poll-read in ONE process - DEFAULT and the only reliable mode; "
            "separate-process set/get returns stale/defaults - documented "
            "GetControlValue trap). Value grammar for 'values': bare number = "
            "double scalar, bare comma-list = double[]; typed prefixes: "
            "dbl: sgl: i8: i16: i32: i64: u8: u16: u32: u64: s:<text> b:true "
            "a:1,2,3 ai: as:a,b ab:true,false a2:[[1,2],[3,4]] ai2: au8: ... "
            "cluster: c:(1,s:hi,b:true,ai:[1,2]) (nested c:() ok; array "
            "elements inside clusters need []). 'outctl' (cycle only) reads a "
            "different control after the run, e.g. cycle NumIn '5' NumOut. "
            "Wrong-type sets are SILENTLY IGNORED by LabVIEW - always check "
            "the ECHO line after set/cycle. Numeric variants coerce into any "
            "numeric representation (verified i8..u64, sgl, dbl). Regression "
            "targets: gen\\fpzoo.vi (typed zoo), Sort 1D Array.vim "
            "(unsorted/sorted array), error.llb\\Clear Errors.vi ('error in "
            "(no error)' mixed cluster). set/cycle WRITE control values - for "
            "user-provided VIs run them on a copy first per the gateway "
            "copy-first rule."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "mode": {"type": "string", "enum": ["get", "set", "setint", "run", "cycle"], "description": "cycle = set+echo+run+poll-read in one process (recommended)"},
                "vi_path": {"type": "string", "description": "Absolute path of the .vi file"},
                "control": {"type": "string", "description": "Control/indicator label, e.g. 'InputArray'"},
                "values": {"type": "string", "description": "Typed value grammar, e.g. 'dbl:3.14', 'i32:5', 's:text', 'b:true', '5,1,3' (double[]), 'c:(1,s:hi,b:true)' (required for set/setint/cycle)"},
                "outctl": {"type": "string", "description": "cycle only: control to read after the run (default = control)"}
            },
            "required": ["mode", "vi_path", "control"]
        }
    },
    {
        "name": "getval",
        "description": (
            "Read the value of ANY block-diagram element or FP control via the "
            "Gateway 'getval' verb (v3.31): the element is flattened with "
            "Variant To Flattened String and the reply (XML: type descriptor "
            "I16 array + data string HEX) is decoded to a human-readable value. "
            "vi_path is a FULL ITEM IDENTIFIER with an optional target: "
            "'<abs .vi path>[|BD|FP]%<ResolverClass>|<Label>' - BD is the "
            "default, the resolver searches BD first then FP. Resolver "
            "classes: NumericConstant, StringConstant, BooleanConstant, "
            "DigitalNumericConstant, ClusterConstant, Constant (any), "
            "Control (FP controls; also reachable via ControlTerminal). "
            "Examples: 'C:x.vi|BD%DigitalNumericConstant|N' (scalar), "
            "'...|BD%ClusterConstant|error constant' (cluster), "
            "'...|FP%Control|ClusterY' (FP cluster control). Decodes all "
            "types: U/I 8..64, SGL, DBL, EXT, complex, BOOL, enum (by item "
            "name), string, path, 1D/2D arrays, clusters (named elements). "
            "FP-CONTROL VALUES ARE RUNTIME-ONLY (not saved with the VI). "
            "getval on a control reads the LIVE value when the VI is open "
            "in the LabVIEW instance (e.g. the user's IDE) and the DEFAULT "
            "when it is closed (fresh open from disk) - verified both ways "
            "(set 7.5/2.25 -> get 7.5/2.25 with the IDE-open VI; 0.0 when "
            "closed). For closed VIs use the arrread tool's 'cycle' mode "
            "(set+run+read in one process). Read-only and lossless (hex "
            "transport)."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "vi_path": {"type": "string", "description": "Full item identifier: '<abs .vi path>%<ResolverClass>|<Label>'"}
            },
            "required": ["vi_path"]
        }
    },
    {
        "name": "search_knowledge",
        "description": (
            "Full-text search over the accumulated LabVIEW code-generation "
            "knowledge (skill-labview-code SKILL.md, gateway-recipe.md "
            "versioned session history v3.x, reference docs, "
            "style_codes.json). Use this BEFORE probing anything "
            "experimentally or when a gateway verb errors - terminal maps, "
            "error causes and proven workflows are usually already recorded "
            "with verification evidence. Example queries: 'connector pane', "
            "'1055', 'Map B', 'FP ITEM SIZE'."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "space-separated words; ALL must appear on the line (case-insensitive)"},
                "max_results": {"type": "integer"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "lv_reference",
        "description": (
            "Structured lookup over VERIFIED LabVIEW code-generation facts "
            "(terminal maps, connector-pane cell tables, wire kinds, resolver "
            "classes, setval representation codes, gateway error-code "
            "meanings, batch-script format). Use this BEFORE wiring or "
            "placing: e.g. query 'feedback' for the Feedback Node terminal "
            "map (random per instance!), 'histogram' or 'linear fit' for "
            "subVI pane cells, 'select' for the s|2/t|3/f|1 rule, 'DBL' for "
            "the setval arg3 code, '1055' for an error's cause. Returns "
            "only facts recorded as gateway-verified, with the recipe "
            "section that verified each. For full-text prose search use "
            "search_knowledge instead."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "space-separated words, ALL must match, e.g. 'feedback', 'add array elements', 'Histogram', 'DBL'"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "lva_session",
        "description": (
            "Persistent-session scripting server call: opens/saves VIs with "
            "session state that SURVIVES between calls (gateway\\LVA\\LVA "
            "Session.vi, driven via lva_call.vbs; a keeper process holds the "
            "COM reference so the LabVIEW instance and its Data Cluster "
            "vi_id registry stay alive). open_vi: open a .vi from disk into "
            "the session, returns reply XML with vi_id (+error cluster; note "
            "vi_id is assigned even when open fails). save_vi: save a "
            "previously opened vi_id to an explicit absolute save_path "
            "(MANDATORY - Save As), returns reply XML with the final path; "
            "EMPTY <Val> = save failed. Verified end-to-end 2026-10-27: "
            "open A -> vi_id 1, open B -> vi_id 2 (registry persists), "
            "save_vi 1 path -> file on disk. Idles at ~0% CPU (20 ms loop "
            "wait). First call may take up to ~90 s if the keeper/LabVIEW "
            "must start."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "tool": {"type": "string", "enum": ["open_vi", "save_vi"],
                          "description": "Which server lane to trigger"},
                "vi_path": {"type": "string",
                             "description": "open_vi: absolute path of the .vi to open (file must exist on disk)"},
                "vi_id": {"type": "integer",
                           "description": "save_vi: session vi_id returned by a previous open_vi"},
                "save_path": {"type": "string",
                               "description": "save_vi: absolute path to Save As (mandatory)"}
            },
            "required": ["tool"]
        }
    },
    {
        "name": "lv_guidance",
        "description": (
            "Static best-practice guidance for LabVIEW code generation: "
            "documentation-access strategy (offline CHM mirror "
            "search_docs/read_doc first; ni.com fallback; vi.lib subVIs via "
            "extract_vi HELP_PATH), programming patterns (event-driven state "
            "machine with enum + shift register; producer/consumer with "
            "queues; error clusters wired through every subVI; connector "
            "pane 4-2-2-4; initialize controls), and codegen guardrails "
            "(verify wires/zero broken flags; errors verb; set auto-index "
            "tunnels to Regular; work on copies). Returns a fixed text; no "
            "inputs. Read once per session before generating code."),
        "inputSchema": {"type": "object", "properties": {}}
    },
    {
        "name": "lva_worker",
        "description": (
            "Drive ONE Scripting Server 2020 worker VI ('Do *.vi' or plain "
            "worker, JanGoebel labview_assistant LV2020 conversion) via COM "
            "in a background 32-bit LV2020 (lva_worker.vbs). Sets FP controls, "
            "runs, waits, reads back. 'set' items use the grammar "
            "'Control=s:value|e:|b:false|i:5' ('|' separates array elements; "
            "e: = Empty/notifier placeholder). 'read' items are control names. "
            "IMPORTANT LIMITATION: session-dependent workers (anything taking "
            "vi_id/object_id) return EMPTY results outside the server context "
            "- the Data Cluster refnum registry cannot cross COM variant "
            "arrays; chains need an in-LabVIEW runner VI - NOW AVAILABLE: "
            "use the lva_session tool (persistent server gateway\\LVA\\LVA "
            "Session.vi) for open_vi/save_vi with surviving session state. "
            "Standalone-drivable "
            "here: the 'Do *.vi' wrappers (verified: Do Get Open VIs.vi, "
            "Do Save VI.vi, Do create project.vi, Do Get Library.vi) with "
            "the flat argument arrays in "
            "skill-labview-code/references/scripting-server-2020.md (e.g. "
            "save_vi Argument = Array(1, abs_path, Empty, False) - explicit "
            "path MANDATORY). Plain API members (get-available-objects.vi, "
            "get_allowed_paths.vi, ...) are NOT standalone-runnable (0x3EB "
            "missing-subVI context) - run vi-scripting-server.vi for those. "
            "path MANDATORY). worker_path may be absolute or a bare filename "
            "resolved in scripting-server\\Scripting Server."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "worker_path": {"type": "string", "description": "Absolute path or filename of the worker .vi"},
                "set": {"type": "array", "items": {"type": "string"}, "description": "Control assignments, e.g. ['save_vi Argument=i:1|s:C:\\tmp\\x.vi|e:|b:false']"},
                "read": {"type": "array", "items": {"type": "string"}, "description": "Control names to read after the run"},
                "sleep_ms": {"type": "integer", "description": "Wait after Run before reading (default 12000)"}
            },
            "required": ["worker_path"]
        }
    },
    {
        "name": "manage_processes",
        "description": (
            "List running LabVIEW processes (pid + executable path, which "
            "reveals 32- vs 64-bit) or force-kill one by pid. Use when COM "
            "fails with 'ClassFactory cannot supply requested class' - usually "
            "an orphan instance with a modal dialog (e.g. 'Save changes?') is "
            "blocking COM activation."),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["list", "kill"]},
                "pid": {"type": "integer"}
            },
            "required": ["action"]
        }
    },
]

TOOLS_IMPL = {
    "extract_vi": tool_extract_vi,
    "list_artifacts": tool_list_artifacts,
    "crop_image": tool_crop_image,
    "stitch_cases": tool_stitch_cases,
    "search_docs": tool_search_docs,
    "read_doc": tool_read_doc,
    "search_ni_docs": tool_search_ni_docs,
    "fetch_ni_doc": tool_fetch_ni_doc,
    "gateway": tool_gateway,
    "gateway_batch": tool_gateway_batch,
    "arrread": tool_arrread,
    "getval": tool_getval,
    "lva_worker": tool_lva_worker,
    "lva_session": tool_lva_session,
    "lv_reference": tool_lv_reference,
    "lv_guidance": tool_lv_guidance,
    "manage_processes": tool_manage_processes,
    "search_knowledge": tool_search_knowledge,
}


# --------------------------------------------------------------------------
# MCP stdio plumbing (newline-delimited JSON-RPC 2.0)
# --------------------------------------------------------------------------

def send(obj):
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


def handle(msg):
    method = msg.get("method")
    mid = msg.get("id")
    if mid is None:
        return  # notification - nothing to answer
    if method == "initialize":
        ver = (msg.get("params") or {}).get("protocolVersion") or "2024-11-05"
        send({"jsonrpc": "2.0", "id": mid, "result": {
            "protocolVersion": ver,
            "capabilities": {"tools": {}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
        }})
    elif method == "tools/list":
        send({"jsonrpc": "2.0", "id": mid, "result": {"tools": TOOLS}})
    elif method == "tools/call":
        params = msg.get("params") or {}
        name = params.get("name")
        args = params.get("arguments") or {}
        impl = TOOLS_IMPL.get(name)
        if impl is None:
            send({"jsonrpc": "2.0", "id": mid, "result": {
                "content": [{"type": "text", "text": "ERROR: unknown tool %r" % name}],
                "isError": True}})
            return
        try:
            text = impl(args)
            send({"jsonrpc": "2.0", "id": mid, "result": {
                "content": [{"type": "text", "text": str(text)}]}})
        except Exception as e:
            log("tool %s failed: %r" % (name, e))
            send({"jsonrpc": "2.0", "id": mid, "result": {
                "content": [{"type": "text", "text": "ERROR: %r" % e}],
                "isError": True}})
    elif method in ("resources/list", "prompts/list"):
        send({"jsonrpc": "2.0", "id": mid, "result": {method.split("/")[0]: []}})
    elif method == "ping":
        send({"jsonrpc": "2.0", "id": mid, "result": {}})
    else:
        send({"jsonrpc": "2.0", "id": mid, "error": {
            "code": -32601, "message": "Method not found: %s" % method}})


def main():
    log("starting; scripts=%s help=%s gateway=%s" % (SCRIPTS, HELP_DIR, GATEWAY_VI))
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except ValueError as e:
            log("ignoring malformed line: %s" % e)
            continue
        try:
            handle(msg)
        except Exception as e:
            log("handler error: %r" % e)
            if msg.get("id") is not None:
                send({"jsonrpc": "2.0", "id": msg["id"], "error": {
                    "code": -32603, "message": "Internal error: %r" % e}})
    log("stdin closed - exiting")


if __name__ == "__main__":
    main()
